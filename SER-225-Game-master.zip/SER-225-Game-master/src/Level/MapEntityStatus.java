package Level;

// This enum represents the different statuses a MapEntity class can have
public enum MapEntityStatus {
    ACTIVE, INACTIVE, REMOVED
}
