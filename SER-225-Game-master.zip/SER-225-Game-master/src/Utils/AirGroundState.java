package Utils;

// Simple enum for keeping track of it something is on the ground or in the air
// I don't like the name of this enum, but I couldn't think of a better name...
public enum AirGroundState {
    GROUND, AIR
}
